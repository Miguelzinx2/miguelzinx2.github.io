anoatual = int(input('Digite o Ano Atual: '))
anodenascimento = int(input('Digite o Ano de Nascimento: '))
 
idade = (anoatual - anodenascimento)
print("Idade: ", idade)
 
if idade>=18:
    print("Você é de maior")
else:
    print("Você é de menor")